-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: j12b110.p.ssafy.io    Database: jjeonchongmu
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gathering_member`
--

DROP TABLE IF EXISTS `gathering_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gathering_member` (
  `gathering_member_id` bigint NOT NULL AUTO_INCREMENT,
  `gathering_attend_count` int DEFAULT NULL,
  `gathering_member_account_balance` bigint DEFAULT NULL,
  `gathering_member_account_deposit` bigint DEFAULT NULL,
  `gathering_member_status` enum('PENDING','ACTIVE','REJECTED') DEFAULT NULL,
  `gathering_payment_status` bit(1) DEFAULT NULL,
  `gathering_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`gathering_member_id`),
  KEY `FK9nt828h7lfx92bjf5rhqosi3b` (`gathering_id`),
  KEY `FKcef2yvtduf1qtgynjym1cvu38` (`user_id`),
  CONSTRAINT `FK9nt828h7lfx92bjf5rhqosi3b` FOREIGN KEY (`gathering_id`) REFERENCES `gathering` (`gathering_id`),
  CONSTRAINT `FKcef2yvtduf1qtgynjym1cvu38` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gathering_member`
--

LOCK TABLES `gathering_member` WRITE;
/*!40000 ALTER TABLE `gathering_member` DISABLE KEYS */;
INSERT INTO `gathering_member` VALUES (1,0,22500,20000,'ACTIVE',_binary '\0',1,7),(2,0,0,30000,'ACTIVE',_binary '\0',2,1),(3,0,15000,30000,'ACTIVE',_binary '\0',3,9),(4,0,0,0,'ACTIVE',_binary '\0',3,8),(5,0,0,0,'ACTIVE',_binary '\0',3,6),(6,0,0,0,'ACTIVE',_binary '\0',3,12),(7,0,0,0,'ACTIVE',_binary '\0',3,11),(10,0,0,10000,'ACTIVE',_binary '\0',4,7),(12,0,0,0,'ACTIVE',_binary '\0',5,14),(13,0,0,0,'ACTIVE',_binary '\0',5,7),(14,0,0,0,'ACTIVE',_binary '\0',6,4),(15,0,0,10000,'ACTIVE',_binary '\0',6,1),(16,0,0,0,'ACTIVE',_binary '\0',7,4),(17,0,0,0,'ACTIVE',_binary '\0',8,7),(18,0,0,0,'ACTIVE',_binary '\0',9,7),(19,0,0,0,'ACTIVE',_binary '\0',10,7),(20,0,0,0,'ACTIVE',_binary '\0',11,7),(21,0,0,0,'ACTIVE',_binary '\0',12,7),(22,0,0,0,'ACTIVE',_binary '\0',13,7),(23,0,0,0,'ACTIVE',_binary '\0',14,7),(24,0,0,0,'ACTIVE',_binary '\0',15,7),(25,0,0,10000,'ACTIVE',_binary '\0',16,1),(26,0,0,0,'ACTIVE',_binary '\0',16,16),(27,0,800,100,'ACTIVE',_binary '\0',17,16),(28,0,0,0,'ACTIVE',_binary '\0',16,17),(29,0,5000,10000,'ACTIVE',_binary '\0',18,11),(31,0,0,0,'ACTIVE',_binary '\0',18,7),(32,0,5000,10000,'ACTIVE',_binary '\0',18,1),(33,0,7499,20000,'ACTIVE',_binary '\0',1,3),(34,0,17500,10000,'ACTIVE',_binary '\0',19,11),(35,0,17500,10000,'ACTIVE',_binary '\0',19,7);
/*!40000 ALTER TABLE `gathering_member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-10 17:19:17
