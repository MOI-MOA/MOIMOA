-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: j12b110.p.ssafy.io    Database: jjeonchongmu
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gathering`
--

DROP TABLE IF EXISTS `gathering`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gathering` (
  `gathering_id` bigint NOT NULL AUTO_INCREMENT,
  `basic_fee` bigint DEFAULT NULL,
  `deposit_date` varchar(255) DEFAULT NULL,
  `gathering_deposit` bigint NOT NULL,
  `gathering_introduction` varchar(255) DEFAULT NULL,
  `gathering_name` varchar(255) NOT NULL,
  `member_count` int DEFAULT NULL,
  `penalty_rate` int DEFAULT NULL,
  `gathering_account_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`gathering_id`),
  UNIQUE KEY `UK_2k4o43p1bilmco6eokpl0rs4` (`gathering_account_id`),
  KEY `FKhfewcf9y29m0l3u64awse9lto` (`user_id`),
  CONSTRAINT `FK13v5sqhib2lg2sgvls7bnejhi` FOREIGN KEY (`gathering_account_id`) REFERENCES `account` (`account_id`),
  CONSTRAINT `FKhfewcf9y29m0l3u64awse9lto` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gathering`
--

LOCK TABLES `gathering` WRITE;
/*!40000 ALTER TABLE `gathering` DISABLE KEYS */;
INSERT INTO `gathering` VALUES (1,10000,'10',20000,'동막초등학교 6학년 2반 동창회 입니다.','동막초등학교 동창회',1,0,14,7),(2,20000,'1',30000,'크로스핏을 시작하는 사람들의 모임','크로스핏투헬',1,0,15,1),(3,15000,'5',30000,'주 1회 풋살 모임','위클리 풋살',1,0,16,9),(4,10000,'2',10000,'중학교 동창회입니다','중학교 2학년2반 동창회',1,0,17,7),(5,0,'1',-2,'心臓を捧げよ!','월 마리아 탈환',1,0,34,14),(6,10000,'15',10000,'대전 4반 모임','대전 4반',1,0,37,4),(7,0,'15',0,'테스트','테스트',1,0,38,4),(8,-5,'1',0,'1','1',1,0,39,7),(9,0,'1',0,'1','1',1,0,40,7),(10,0,'0',0,'1','모임 모두 0원 설정',1,0,41,7),(11,0,'1',0,'1','모임 0원',1,0,42,7),(12,1,'1',0,'1','모임 보증금 0원',1,0,43,7),(13,0,'1',1,'1','모임 회비만 0원',1,0,44,7),(14,1,'1',1,'1','패널티 설정 0퍼',1,0,45,7),(15,0,'1',0,'0','000090909',1,0,46,7),(16,10000,'12',10000,'서울벙개모임','23기',1,0,47,1),(17,1000,'50000',100,'ajja','dd',1,0,49,16),(18,10000,'2',10000,'동창회','중학교 동창회',1,0,53,11),(19,10000,'10',10000,'대전4반 모여','싸피12기 대전4반',1,0,63,11);
/*!40000 ALTER TABLE `gathering` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-10 17:19:15
