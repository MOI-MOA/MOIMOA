-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: j12b110.p.ssafy.io    Database: jjeonchongmu
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `birth` date DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `user_key` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UK_6dotkott2kjsp8vw4d0m25fb7` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'1990-01-01','2025-04-09 09:40:01.028991','lee@example.com','이다영','$2a$10$XeMi5Hz.oynpJm5WfY0kseWbV0fOPubUzGxxa9utbGu61YCdzSY9u',NULL,'6ee20bb1-b5e0-49a2-a739-480039d19233'),(2,'1999-01-01','2025-04-09 09:42:05.619820','bae@example.com','배한진','$2a$10$nMz7/QMG9Azhq3N4VAGJyOY5zvqt5ErJ/0TqiB4GJz6P7JHec7d0m',NULL,'6e5ae80c-c758-4549-9dc4-472e0b5078a9'),(3,'1995-01-01','2025-04-09 09:42:37.394587','jin@example.com','진종수','$2a$10$OukGb25F6AKmcf2kCI25J.OUHdEz93TWf5NLirAT1KUxQAookY8W2',NULL,'64601f3a-7e51-46aa-8bc6-73dad18662a2'),(4,'2000-01-01','2025-04-09 09:43:14.369999','ham@example.com','함동건','$2a$10$RIL8gbEB6nXLHT.mVYF3F.Ce3uFatQ1KZdtuUJ2BVhacCWTZujALq',NULL,'01a42056-5b21-4bd0-9692-83dc507f7560'),(5,'1998-01-01','2025-04-09 09:43:44.659749','leee@example.com','이동영','$2a$10$XBPDiZXXjYf3YMYzlRLelOotGcEqG2Pb87uoDBOj5GhTf5tzREA0C',NULL,'6aa0d5cd-b218-44ef-816a-a53f7f723d1d'),(6,'1995-01-01','2025-04-09 09:51:34.949464','jung@example.com','정다혜','$2a$10$MylBFU2u6YxS54o4UxNkn.4Ek7Fsbnd/29EVtW1lECK9aPHfLhlRS',NULL,'65583421-d3d8-40a2-8fac-1d0b1199b3ab'),(7,'2003-02-13','2025-04-09 09:52:00.977487','kim@example.com','김철수','$2a$10$ONcfGsefp.cUFj7Y20QH4uHNv46Ib7b77jHwnLzKi/54cOVM0THOa',NULL,'ae955206-ccab-417b-814e-f8402b9072fd'),(8,'1991-01-01','2025-04-09 09:52:04.794392','kang@example.com','강현우','$2a$10$yEv5Y3FMRsaIDMiFJGTbjeq6mfTUCWLJBk27Rha6UQk63qZ3Xcg3K',NULL,'a90aacd2-a2ed-4356-9516-ccf798b5d867'),(9,'1987-01-02','2025-04-09 09:52:30.650398','shin@example.com','신지원','$2a$10$SBIEt75oZpxYAPj5arO8kePE7eJvq2/MGHpL5/2eQ5W8JhTBw1F4e',NULL,'1a6c3093-ba5a-4ec7-87e8-e6d5178288b7'),(10,'1993-01-03','2025-04-09 09:53:12.162992','yoon@example.com','윤서연','$2a$10$ckt/9IMdJve3IUojX2m3JO9WToR4BRjOdMcT6PIc9n.gyb68TqZeO',NULL,'e77becc5-3b09-417b-9b74-94874e31e6a3'),(11,'2008-06-20','2025-04-09 09:53:43.280722','leeee@example.com','이영희','$2a$10$Gbn6sLbTozW9jDVjUzANU.laXk4DsTtiedLfIGaTCwZTwgRTU/k1K',NULL,'802bb6ee-cbe5-4fde-a3c4-033531e93aae'),(12,'1998-07-03','2025-04-09 09:56:03.002059','park@example.com','박지성','$2a$10$VfsTIrMDxaCLJgO6.KXIW.2XUCXCVzWbrpmfsvSzrH1CDh5NoS1Vm',NULL,'410ee9c3-b717-4d7c-81b9-e35ef1ce95fd'),(13,'1995-10-19','2025-04-09 09:57:54.385108','choi@example.com','최민수','$2a$10$.ihDXms5lDj0smISnVaG.e69hUErqdYRbWh.T63F/vpC5NcDpSy/S',NULL,'d6a89ec3-bd1b-4c76-9306-670b54ac4b8a'),(14,'0835-02-09','2025-04-09 17:14:20.825727','mikas@wall.maria','미카사아커만','$2a$10$3SsLj1.odhW7ZcU8ELcmN.M4b54B3POIl1WrN8XfWVxpmlWY39fHa',NULL,'8a5d4098-1383-4843-85cf-ae7ecd046b76'),(15,'0835-03-29','2025-04-09 17:20:25.217858','eren@yeager.wall','에렌 예거','$2a$10$Z7MNAlzAHwR9Kc7Ly4v6GujxUBHQw9kICowWzP0yUuNjOx0YVNBm2',NULL,'e157fc6f-86ce-44c9-bf05-458bbe5bfa57'),(16,'2024-09-04','2025-04-09 20:41:25.129486','gu@naver.com','신짱구','$2a$10$RGA8JQy8EuLxM4r3rScvAO87EgsA4VDjUgJMnKpvlnkOcoBE.u/bO',NULL,'acdec5cf-a67b-47cc-a2ae-7a19a28dbfac'),(17,'1994-03-14','2025-04-09 21:00:23.423312','inbh314@naver.com','김희진','$2a$10$XsEjKL8fgb9DA.37cp3RW.5dC.7T2i/5XrxhmyGQvkzW1MciH2Tou',NULL,'94c693ac-1be7-44c3-930a-15b7d22f57e9'),(18,'1941-12-03','2025-04-10 13:52:42.292630','dong@example.com','동해수산','$2a$10$73LCArlajUdaWjinctWYLezxc7DYy/OSPG1aENTQZQjgpCf4Stauq',NULL,'13ffaf02-2a0a-49d9-b5aa-048a887f2091'),(19,'1901-02-01','2025-04-10 16:41:38.804966','bbaaee11@naver.com','한진배','$2a$10$DnKkCs55urJsKkmgWRDA4ufqLuZQS6T2xS8n0DIR2FirbigQQVsPG',NULL,'0d065d9f-d424-4f49-a1a0-4507a76a2696'),(20,'1999-09-18','2025-04-10 16:44:40.812377','lee123@example.com','립제이','$2a$10$baHpxEcSUmaHtn4hMZRuGOCdnMWeR9wFZ932OzLewEUBNbBqv.OF.',NULL,'64325abd-23b0-4281-863c-51aa87d21737');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-10 17:19:14
