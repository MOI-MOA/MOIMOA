-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: j12b110.p.ssafy.io    Database: jjeonchongmu
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule` (
  `schedule_id` bigint NOT NULL AUTO_INCREMENT,
  `schedule_detail` varchar(255) NOT NULL,
  `penalty_apply_date` datetime(6) NOT NULL,
  `penalty_rate` int DEFAULT NULL,
  `per_budget` bigint NOT NULL,
  `schedule_place` varchar(255) NOT NULL,
  `schedule_start_time` datetime(6) NOT NULL,
  `schedule_status` int DEFAULT NULL,
  `schedule_title` varchar(255) NOT NULL,
  `gathering_id` bigint NOT NULL,
  `schedule_account_id` bigint DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`schedule_id`),
  UNIQUE KEY `UK_rlk6ya5ys0515cwoitekd1w99` (`schedule_account_id`),
  KEY `FKgckbudg1g7jsso5yh1ue3828g` (`gathering_id`),
  KEY `FKdn5svbxyacce1gpfiawk7iqtc` (`user_id`),
  CONSTRAINT `FK6hhe1cj5rk8krkmwmg6e2ewpa` FOREIGN KEY (`schedule_account_id`) REFERENCES `account` (`account_id`),
  CONSTRAINT `FKdn5svbxyacce1gpfiawk7iqtc` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `FKgckbudg1g7jsso5yh1ue3828g` FOREIGN KEY (`gathering_id`) REFERENCES `gathering` (`gathering_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES (1,'모두참석바람','2025-04-18 00:00:00.000000',50,10000,'동백중학교','2025-04-24 00:00:00.000000',0,'회식',4,18,7),(2,'뒤풀이 회식입니다','2025-04-02 00:00:00.000000',50,10000,'강남','2025-04-26 00:00:00.000000',0,'25일 뒤풀이 회식',4,19,11),(3,'모두참석바람','2025-04-10 15:00:00.000000',11,11,'11','2025-04-11 15:00:00.000000',0,'11일 10일',4,20,11),(4,'모두참석바람','2025-04-10 15:00:00.000000',10,1000,'장','2025-04-24 15:00:00.000000',0,'24일 뒤풀이',4,21,11),(5,'11','2025-04-26 06:00:00.000000',11,11,'11','2025-04-27 06:00:00.000000',0,'27, 26',1,22,7),(6,'11','2025-04-18 06:00:00.000000',11,11,'11','2025-04-25 06:00:00.000000',0,'25test',1,23,7),(7,'11','2025-04-22 06:00:00.000000',11,11,'11','2025-04-23 06:00:00.000000',0,'23',1,24,7),(8,'21','2025-04-20 06:00:00.000000',11,11,'11','2025-04-21 06:00:00.000000',0,'21',1,25,7),(9,'11','2025-04-18 06:00:00.000000',11,11,'11','2025-04-19 06:00:00.000000',0,'19',1,26,7),(10,'17','2025-04-16 06:00:00.000000',11,11,'11','2025-04-17 06:00:00.000000',0,'127',1,27,7),(11,'14','2025-04-13 06:00:00.000000',14,14,'14','2025-04-14 06:00:00.000000',0,'14',1,28,7),(12,'','2025-04-14 06:00:00.000000',1,1,'1','2025-04-15 06:00:00.000000',0,'일정 15일 패널티 14일',1,29,7),(13,'1','2025-04-14 15:00:00.000000',1,1,'1','2025-04-15 15:00:00.000000',0,'일정 15일 패널티 14일',1,30,7),(14,'`','2025-07-01 21:00:00.000000',1,1,'1','2025-07-31 21:00:00.000000',0,'7월 31일 패널티 7월 1일 오후 9시',1,31,7),(15,'1','2025-04-09 15:00:00.000000',1,1,'1','2025-04-09 15:00:00.000000',0,'일정 9일 패널티 9일',1,32,7),(16,'1차 탐색 작전','2025-04-10 15:00:00.000000',100,0,'방벽 앞','2025-04-10 15:00:00.000000',0,'',5,35,14),(17,'테스크','2025-04-30 15:00:00.000000',5,100,'신림역','2025-04-23 15:00:00.000000',0,'',17,50,16),(18,'11','2025-04-29 15:00:00.000000',11,11,'11','2025-04-30 15:00:00.000000',0,'30',1,52,7);
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-10 17:19:13
